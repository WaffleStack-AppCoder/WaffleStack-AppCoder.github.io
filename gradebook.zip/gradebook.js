function fetchGradeDate(){
    console.log("Fetching Grade Data...");
}

function popularGradebook(data){
    console.log("Populating Grade Data: ", data);
}

const gradeData = fetchGradeDate();
popularGradebook(gradeData);