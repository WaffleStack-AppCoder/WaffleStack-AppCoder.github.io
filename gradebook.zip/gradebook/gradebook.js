function fetchGradeDate(){
    console.log("Fetching Grade Data...");
    //Creating request for HTTP Data
    let xhr = new XMLHttpRequest();

    let apiRoute = "/api/grades";

    xhr.onreadystatechange = function(){
        let results;
        //Check if I'm Done
        if (xhr.readyState === xhr.DONE){
            if (xhr.status !== 200){
                console.error(`could not retrive grades, try again. 404 Status: ${xhr.status}`);
            }

            popularGradebook(JSON.parse(xhr.responseText));
        }
    }.bind(this);
    xhr.open("get", apiRoute, true);
    xhr.send();
}

function popularGradebook(data){
    console.log("Populating Grade Data: ", data);
    let tableElm = document.getElementById("gradebook");

    data.forEach(function(assignment){
        let row = document.createElement("tr");

        let columns = [];

        columns.name = document.createElement("td");
        columns.name.appendChild(
            document.createTextNode(assignment.total_grade)
        );

        row.append(columns.name);
        row.append(columns.grade);

        tableElm.appendChild(row);
    });
}

